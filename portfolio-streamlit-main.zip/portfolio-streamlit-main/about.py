import streamlit as st

def about_me():
    st.subheader('Nama saya adalah Willy')
    st.write('Saya seorang Data Scientist')
    st.write('Saya dulunya seorang pekerja Tambang')