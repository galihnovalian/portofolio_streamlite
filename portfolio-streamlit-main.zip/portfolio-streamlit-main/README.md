# portfolio-streamlit

Ini adalah project streamlit pertama saya

Jika ingin mengakses dengan lebih interaktif, bisa kunjungi https://ds29latihan.streamlit.app/
